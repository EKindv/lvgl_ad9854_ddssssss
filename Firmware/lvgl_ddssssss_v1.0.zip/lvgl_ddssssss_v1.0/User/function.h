#ifndef __FUNCTION_H
#define __FUNCTION_H	

void process_command(char *cmd);



#endif
