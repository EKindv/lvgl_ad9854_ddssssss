#ifndef  __TIMER_H
#define  __TIMER_H

void timer_init(uint16_t arr,uint16_t psc);

#endif
